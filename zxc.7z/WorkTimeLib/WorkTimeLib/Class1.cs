﻿namespace WorkTimeLib
{
    public class Class1
    {

    }
}