﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace MSTest
{
    [TestClass]
    public class Calculations
    {
        [TestMethod]
        public void AvailablePeriods()
        {
            TimeSpan[] startTimes = new TimeSpan[]
            {
                new TimeSpan(10,00,00),
                new TimeSpan(10,00,00),
                new TimeSpan(10,00,00),
                new TimeSpan(10,00,00),
                new TimeSpan(10,00,00),
            };

            int[] durations = [60, 30, 10, 10, 40];
            TimeSpan beginWorkingTime = new TimeSpan(8, 0, 0);
            TimeSpan endWorkingTime = new TimeSpan(18, 0, 0);
            int consultationTime = 30;

            string[] expected = new string[]
            {
                "08:00 - 08:30",
                "08:30 - 09:00",
                "09:00 - 09:30",
                "09:30 - 10:00",
                "10:00 - 10:30",
                "10:30 - 11:00",
                "11:30 - 12:00",
                "12:00 - 12:30",
                "08:00 - 08:30",
            };
        }
    }
}
